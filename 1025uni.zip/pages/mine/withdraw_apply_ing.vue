<template>
	<view class=" overflow-hidden">
		<view
			style="width: 100%;display: flex;align-items: center;justify-content: center;font-weight: 500;font-size: 29rpx;color: #313131;flex-direction: column;margin-top:100rpx;line-height: 1.5;">
			<!-- <image style="width: 84rpx;height: 84rpx;"
				src="https://saas.jizhongkeji.com/static/jzkj/images/with_ing.png">
			</image> -->
			<image style="width: 84rpx;height: 84rpx;"
				src="../../static/icon/withdraw.svg">
			</image>

			<view style="margin-top:40rpx">你的提现申请已完成提交</view>
			<view>等待财务人员审核</view>
		</view>

		<view
			style="width: 375rpx;height: 74rpx;background: #FF4F26;border-radius: 14rpx 14rpx 14rpx 14rpx;font-weight: 400;font-size: 31rpx;color: #FFFFFF;display: flex;align-items: center;justify-content: center;position: fixed;bottom: 200rpx;left:50%;transform: translateX(-50%);"
			bindtap="to_home">返回</view>
	</view>
</template>

<script setup>

</script>

<style></style>
