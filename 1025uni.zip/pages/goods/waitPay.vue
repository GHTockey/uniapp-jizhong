<template>
	<view style="background-color: aqua;">
		123
	</view>
</template>

<script setup>

</script>

<style scoped></style>